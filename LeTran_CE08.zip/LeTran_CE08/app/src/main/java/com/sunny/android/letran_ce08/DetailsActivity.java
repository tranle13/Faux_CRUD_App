
	// Name: Tran Le
	// AID - 1808
	// File name: DetailsActivity.java

package com.sunny.android.letran_ce08;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.sunny.android.letran_ce08.fragments.DetailsFragment;

public class DetailsActivity extends AppCompatActivity implements DetailsFragment.DeleteOrNot {

	// Member variables
	private static final String DELETE_KEY = "DELETE_MOUNT";
	private static final String SHARE_KEY = "SHARE_MOUNT";
	private static final int SHARE_REQUEST = 3;
	private Mount chosenMount = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_details);

		Intent receiver = getIntent();
		chosenMount = (Mount)receiver.getSerializableExtra(MainActivity.VIEW_MOUNT_KEY);

		if (chosenMount != null) {
			getSupportFragmentManager().beginTransaction().add(R.id.detailsFragmentHolder,
					DetailsFragment.newInstance(chosenMount)).commit();
		}
	}

	// Implement methods of interface
	@Override
	public void deleteOrNot() {
		Intent returnIntent = new Intent();
		returnIntent.putExtra(DELETE_KEY, true);

		setResult(RESULT_OK, returnIntent);

		finish();
	}

	@Override
	public void shareOrNot() {
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		shareIntent.putExtra(SHARE_KEY, chosenMount.toString());
		shareIntent.setType("text/plain");
		startActivityForResult(shareIntent, SHARE_REQUEST);

	}
}
