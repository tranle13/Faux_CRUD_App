
	// Name: Tran Le
	// AID - 1808
	// File name: FormActivity.java

package com.sunny.android.letran_ce08;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.sunny.android.letran_ce08.fragments.FormFragment;

public class FormActivity extends AppCompatActivity implements FormFragment.MountCreation {

	// Member variables
	public static final String NEW_MOUNT_KEY = "MOUNT_CREATION";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_form);

		getSupportFragmentManager().beginTransaction().add(R.id.formFragmentHolder,
				FormFragment.newInstance()).commit();
	}

	// Implement method of interface
	@Override
	public void createMount(Mount newMount) {
		if (newMount != null) {
			Intent returnIntent = new Intent();
			returnIntent.putExtra(NEW_MOUNT_KEY, newMount);
			setResult(RESULT_OK, returnIntent);

			finish();
		}
	}

}
