
	// Name: Tran Le
	// AID - 1808
	// File name: MainActivity.java

package com.sunny.android.letran_ce08;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.sunny.android.letran_ce08.fragments.DetailsFragment;
import com.sunny.android.letran_ce08.fragments.ListViewFragment;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ListViewFragment.GetChosen {

	// Member variables
	private ArrayList<Mount> mounts = new ArrayList<>();
	private Context context;
	private static final int TO_FORM_ACTIVITY = 1;
	private static final int TO_DETAILS_ACTIVITY = 2;
	private int chosenIndex = -1;
	public static final String VIEW_MOUNT_KEY = "MOUNT_VIEW";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Toolbar toolbar = findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);

		context = this;

		getSupportFragmentManager().beginTransaction().add(R.id.listFragmentHolder,
					ListViewFragment.newInstance(this.mounts)).commit();

		// Add fragment
		FloatingActionButton fab = findViewById(R.id.fab);
		fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent formIntent = new Intent(context, FormActivity.class);
				startActivityForResult(formIntent, TO_FORM_ACTIVITY);
			}
		});
	}

	// Function to check the result code and request code to carry out the actions
	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK && requestCode == TO_FORM_ACTIVITY) {
			try {
				Mount newPet = (Mount) data.getSerializableExtra(FormActivity.NEW_MOUNT_KEY);
				if (newPet != null) {
					mounts.add(newPet);
					getSupportFragmentManager().beginTransaction().replace(R.id.listFragmentHolder,
							ListViewFragment.newInstance(this.mounts)).commit();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (resultCode == RESULT_OK && requestCode == TO_DETAILS_ACTIVITY) {
			try {
				if (data.getBooleanExtra(DetailsFragment.CHOSEN_MOUNT_KEY, true)) {
					if (chosenIndex != -1) {
						mounts.remove(chosenIndex);
						Toast.makeText(context, getString(R.string.toast_delete), Toast.LENGTH_SHORT).show();
						getSupportFragmentManager().beginTransaction().replace(R.id.listFragmentHolder,
								ListViewFragment.newInstance(this.mounts)).commit();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// Implement method of interface
	@Override
	public void theChosen(int position) {
		Intent detailsIntent = new Intent(context, DetailsActivity.class);
		detailsIntent.putExtra(VIEW_MOUNT_KEY, mounts.get(position));

		startActivityForResult(detailsIntent, TO_DETAILS_ACTIVITY);

		chosenIndex = position;
	}
}
