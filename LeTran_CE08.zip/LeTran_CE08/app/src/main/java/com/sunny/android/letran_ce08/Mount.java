
	// Name: Tran Le
	// AID - 1808
	// File name: Mount.java

package com.sunny.android.letran_ce08;

import java.io.Serializable;

public class Mount implements Serializable {

	// Member variables
	private final String name;
	private final Integer level;
	private final String kind;
	private final String dye;

	// Constructor
	public Mount(String name, Integer level, String kind, String dye) {
		this.name = name;
		this.level = level;
		this.kind = kind;
		this.dye = dye;
	}

	// Getters
	public String getName() {
		return name;
	}

	public Integer getLevel() {
		return level;
	}

	public String getKind() {
		return kind;
	}

	public String getDye() {
		return dye;
	}

	@Override
	public String toString() {
		return getName();
	}
}
