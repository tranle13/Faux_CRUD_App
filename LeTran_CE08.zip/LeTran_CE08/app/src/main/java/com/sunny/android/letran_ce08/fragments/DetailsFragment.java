
	// Name: Tran Le
	// AID - 1808
	// File name: DetailsFragment.java

package com.sunny.android.letran_ce08.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sunny.android.letran_ce08.Mount;
import com.sunny.android.letran_ce08.R;

public class DetailsFragment extends Fragment {

	// Member variables
	public static final String CHOSEN_MOUNT_KEY = "CHOSEN_MOUNT";
	private DeleteOrNot delete_interface;

	public DetailsFragment() {
		// Required empty public constructor
	}

	// Interface creation
	public interface DeleteOrNot {
		void deleteOrNot();
		void shareOrNot();
	}

	// Function used to create fragment
	public static DetailsFragment newInstance(Mount chosenMount) {
		DetailsFragment fragment = new DetailsFragment();
		Bundle args = new Bundle();
		args.putSerializable(CHOSEN_MOUNT_KEY, chosenMount);
		fragment.setArguments(args);
		return fragment;
	}

	// Function to add options menu to fragment
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	// Function to check if activity implements fragment's interface
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);

		if (context instanceof DeleteOrNot) {
			delete_interface = (DeleteOrNot)context;
		}
	}

	// Return the view for fragment
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		return inflater.inflate(R.layout.fragment_details, container, false);
	}

	// Assign values of the mount to TextViews
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		if (getArguments() != null) {
			Mount chosen = (Mount)getArguments().getSerializable(CHOSEN_MOUNT_KEY);
			if (chosen != null && getView() != null) {
				((TextView)getView().findViewById(R.id.txt_Name)).setText(chosen.getName());
				((TextView)getView().findViewById(R.id.txt_Level)).setText(chosen.getLevel().toString());
				((TextView)getView().findViewById(R.id.txt_Kind)).setText(chosen.getKind());
				((TextView)getView().findViewById(R.id.txt_Dye)).setText(chosen.getDye());
			}
		}
	}

	// Function to create options menu
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);

		inflater.inflate(R.menu.trash_menu, menu);
	}

	// Function to assign handler to options menu item click listener
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.trash_button:
				delete_interface.deleteOrNot();
				break;
			case R.id.share_button:
				delete_interface.shareOrNot();
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
