
	// Name: Tran Le
	// AID - 1808
	// File name: FormFragment.java

package com.sunny.android.letran_ce08.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.sunny.android.letran_ce08.Mount;
import com.sunny.android.letran_ce08.R;

public class FormFragment extends Fragment {

	// Member variable
	private MountCreation mount_interface;

	public FormFragment() {
		// Default empty constructor
	}

	// Interface creation
	public interface MountCreation {
		void createMount (Mount newMount);
	}

	// Function used to create fragment
	public static FormFragment newInstance() {

		Bundle args = new Bundle();

		FormFragment fragment = new FormFragment();
		fragment.setArguments(args);
		return fragment;
	}

	// Function to check if activity implements fragment's interface
	@Override
	public void onAttach(Context context) {
		super.onAttach(context);

		if (context instanceof MountCreation) {
			mount_interface = (MountCreation)context;
		}
	}

	// Function to add options menu to fragment
	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	// Return the view for fragment
	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		return inflater.inflate(R.layout.form_fragment, container, false);
	}

	// Function to create options menu
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		inflater.inflate(R.menu.save_menu, menu);
	}

	// Function to assign handler to options menu item click listener
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.save_button:
				Mount newMount = null;
				if (getView() != null) {
					EditText name = getView().findViewById(R.id.etx_Name);
					EditText level = getView().findViewById(R.id.etx_Level);
					EditText kind = getView().findViewById(R.id.etx_Kind);
					EditText dye = getView().findViewById(R.id.etx_Dye);

					String strName = name.getText().toString();
					String strLevel = level.getText().toString();
					String strKind = kind.getText().toString();
					String strDye = dye.getText().toString();

					if (strName.isEmpty()) {
						name.setError(getString(R.string.error));
					} else if (strLevel.isEmpty()) {
						level.setError(getString(R.string.error));
					} else if (strKind.isEmpty()) {
						kind.setError(getString(R.string.error));
					} else if (strDye.isEmpty()) {
						dye.setError(getString(R.string.error));
					} else {
						try {
							Integer intLevel = Integer.parseInt(strLevel);
							newMount = new Mount(strName, intLevel, strKind, strDye);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}

				mount_interface.createMount(newMount);
				break;
		}
		return super.onOptionsItemSelected(item);
	}
}
