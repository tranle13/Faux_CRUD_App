
	// Name: Tran Le
	// AID - 1808
	// File name: ListViewFragment.java

package com.sunny.android.letran_ce08.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.sunny.android.letran_ce08.Mount;
import com.sunny.android.letran_ce08.R;

import java.util.ArrayList;

public class ListViewFragment extends ListFragment {

	// Member variables
	private static final String MOUNT_KEY = "MOUNT_KEY";
	private GetChosen chosen_interface;

	public ListViewFragment() {
		// Default empty constructor
	}

	public interface GetChosen {
		void theChosen(int position);
	}

	// Create an instance of fragment
	public static ListViewFragment newInstance(ArrayList<Mount> mounts) {

		Bundle args = new Bundle();

		args.putSerializable(MOUNT_KEY, mounts);

		ListViewFragment fragment = new ListViewFragment();
		fragment.setArguments(args);
		return fragment;
	}

	// Return fragment view
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.listview_fragment, container, false);
	}

	@Override
	public void onAttach(Context context) {
		super.onAttach(context);

		if (context instanceof GetChosen) {
			chosen_interface = (GetChosen)context;
		}
	}

	// Get the ArrayList from args and set adapter to list
	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		if (getArguments() != null) {
			ArrayList<Mount> mounts = (ArrayList<Mount>)getArguments().getSerializable(MOUNT_KEY);

			if (getActivity() != null && mounts != null) {
				ArrayAdapter<Mount> adapter = new ArrayAdapter<>(getActivity(),
						android.R.layout.simple_list_item_1, mounts);
				setListAdapter(adapter);
			}
		}
	}

	// Function to handle click event on list item
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);

		chosen_interface.theChosen(position);
	}
}
